<template>
    <el-descriptions title="学生信息" style="color: aliceblue;">
    <el-descriptions-item label="学生">张三</el-descriptions-item>
    <el-descriptions-item label="学号">19219204</el-descriptions-item>
    <el-descriptions-item label="课程名称">操作系统课程设计</el-descriptions-item>
    <el-descriptions-item label="备注">
      <el-tag size="small">南京农业大学</el-tag>
      <el-tag size="small" type="danger">操作系统</el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="课设开始时间">
      第五天
    </el-descriptions-item>
    <el-descriptions-item label="任课老师">
      姜海燕
    </el-descriptions-item>
</el-descriptions>

</template>
<script>
 export default{
  name:'Student_Info'
 }
</script>