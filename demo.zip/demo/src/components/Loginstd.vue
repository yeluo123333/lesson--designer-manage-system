<template>
  <div class="container">
    <div class="login">
      <h2 style="color: aliceblue;">Login</h2>
      <form>
        <div class="form-group">
          <label for="username" style="color: aliceblue;">Username:</label>
          <input type="text" id="username" v-model="username" />
        </div>
        <div class="form-group">
          <label for="password" style="color: aliceblue;">Password:</label>
          <input type="password" id="password" v-model="password" />
        </div>
        <div style="display: flex;flex-direction: row;margin-top: 60px;">
          <el-radio v-model="radio" label="学生">学生</el-radio>
          <el-radio v-model="radio" label="教师">教师</el-radio>
        </div>
        <div class="form-group">
          <button type="button" @click="login">Login</button>
        </div>
      </form>
    </div>
  </div>
</template>

 
 <script>
 export default {
   name: "Login-student",
   data() {
     return {
       username: "",
       password: "",
       radio: '学生'

     };
   },
   methods: {
     login() {
       // 进行登录验证的逻辑，比如发送请求到服务器等
       console.log(`Username: ${this.username}, Password: ${this.password}, id: ${this.radio}`);
       if(this.radio=='学生'){
        this.$router.push('/student')
       }
       else
       this.$router.push('/main')
     },
   },
 };
 </script>
 
 <style scoped>
 .login {
   max-width: 400px;
   margin-top: 10% ;
   text-align: center;
   width: 400px;
  height: 300px;

 }
 
 .form-group {
   margin: 10px 0;
 }
 
 label {
   display: block;
   font-weight: bold;
 }
 
 input[type="text"],
 input[type="password"] {
   padding: 5px;
   width: 100%;
   border-radius: 5px;
   border: 1px solid #ccc;
   box-sizing: border-box;
 }
 
 button {
   padding: 10px;
   border-radius: 5px;
   border: none;
   background-color: #42b983;
   color: #fff;
   cursor: pointer;
   transition: background-color 0.3s ease;
 }
 
 button:hover {
   background-color: #1d8e42;
 }
 .container {
  display: flex;
  justify-content: center;
  align-items: center;
}

 </style>
 