<template>
  <div>
    <HeaderTap>
    </HeaderTap>
  <div id="container"> 
    <el-upload class="upload-demo" ref="upload" action="http://127.0.0.1:5000/"
      :on-preview="handlePreview" :on-remove="handleRemove" :file-list="fileList" :auto-upload="false"
      style="margin-left: 10%;" :on-change="handleUploadChange"
      :before-upload="beforeUpload">
      
      <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
      <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器</el-button>
      <el-input placeholder="请输入每人需测试人数" v-model="input" clearable style="width: 29%;margin-top: 10%; margin-left: 5%;">
      </el-input>
      <el-button type="danger" style=" margin-left: 5%;" size="small">提交</el-button>
      <div slot="tip" class="el-upload__tip" style="color: aliceblue;">上传学生名单的excel文件
        <el-button type="warning" plain size="mini" disabled  style="margin-left: 80%;">下载名单</el-button>
      </div>
      
    </el-upload>
    <StudentnameList :message="input" style="margin-top: 3%;"></StudentnameList>
  </div>
  </div>

</template>

<script>


import StudentnameList from './StudentnameList.vue'
import HeaderTap from './HeaderTap.vue'
import axios from 'axios'

export default {
  name: "teacher_index",
  components: {
    StudentnameList,
    HeaderTap,
    
},
  data() {
    return {
      fileList: [],
      input:'',
      formData: new FormData()
    };
  },
  methods: {
    submitUpload() {
      this.$refs.upload.submit();
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    beforeUpload(file) {
      // 检查文件类型和大小等信息
      // 如果返回 false，文件将停止上传
      // 如果需要修改上传的文件，可以在这里进行处理，例如添加自定义字段
      this.formData.append('file', file);
      return true;
    },
    handleUploadChange(file) {
      // 上传成功的回调函数
      console.log(file);
    },
    uploadFile() {
      axios.post(this.uploadUrl, this.formData).then((response) => {
        console.log(response.data);
      });
    }
  },

};
function createStar() {
  var star = document.createElement('div');
  star.className = 'star';
  star.style.left = Math.random() * window.innerWidth + 'px';
  star.style.top = Math.random() * window.innerHeight + 'px';
  document.body.appendChild(star);
  setTimeout(function () {
    star.remove();
  }, 5000);
}
function createShootingStar() {
  var shootingStar = document.createElement('div');
  shootingStar.className = 'shooting-star';
  var tail = document.createElement('div');
  tail.className = 'tail';
  shootingStar.appendChild(tail);
  shootingStar.style.left = '-20px';
  shootingStar.style.top = Math.random() * window.innerHeight + 'px';
  shootingStar.style.transform = 'rotate(' + Math.random() * 360 + 'deg)';
  document.body.appendChild(shootingStar);
  setTimeout(function () {
    shootingStar.remove();
  }, 5000);
}
setInterval(createStar, 50);
setInterval(createShootingStar, 10000);

</script>

<style>
body {
  background-color: black;
}

.star {
  position: absolute;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background-color: white;
  z-index: 1;
}

.shooting-star {
  position: absolute;
  z-index: 2;
}

.tail {
  position: absolute;
  width: 10px;
  height: 1px;
  background-color: white;
  z-index: 2;
}
</style>

