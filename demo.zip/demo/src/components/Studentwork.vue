<template>
    <div>
        <Student_Header></Student_Header>
        <Student_Info style="margin-top: 2%;"></Student_Info>
        <div style="display: flex;flex-direction: row;margin-top: 15%;margin-left: 10%;">
            <div>
                <el-upload class="upload-demo" drag action="https://jsonplaceholder.typicode.com/posts/" multiple>
                    <i class="el-icon-upload"></i>
                    <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                    <div class="el-upload__tip" slot="tip" style="color: white;">上传每天的工作总结</div>
                </el-upload>
            </div>
            <div style="display: flex;justify-content: flex-end;margin-left: 30%;">
                 
                <work_Card style="margin-top:3% ;"></work_Card>
            </div>
        </div>

    </div>
</template>
<script>
import Student_Info from './Student_Info.vue';
import Student_Header from './Student_Header.vue';
import work_Card from './work_Card.vue';
export default {
    name: 'studentWork',
    components: {
        Student_Info,
        Student_Header,
        work_Card
    }
}
</script>