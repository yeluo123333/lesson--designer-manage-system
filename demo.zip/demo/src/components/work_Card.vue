<template>
    <div class="card-container">
      <el-card class="box-card" shadow="hover">
        <div v-for="o in worklist" :key="o" class="text item">
          {{o}}
        </div>
      </el-card>
    </div>
  </template>
  
  <style>
    .text {
      font-size: 14px;
    }
  
    .item {
      padding: 18px 0;
      color: aliceblue;
    }
  
    .box-card {
      width: 480px;
      backdrop-filter: blur(5px);
      background-color: rgba(255, 255, 255, 0.3);
      border: none;
    }
  
    .card-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 30vh;
      background: linear-gradient(45deg, #2b37e2, #50c5ff);
    }
  </style>
  
  <script>
  export default {
    name: 'Work_card',
    data(){
        return{
            worklist:['完成互测','填写自测评价报告','完善修改课设代码']
        }
      
    }
  }
  </script>
  