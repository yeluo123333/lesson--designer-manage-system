<template>
    <el-menu :default-active="activeIndex2" class="el-menu-demo" mode="horizontal" @select="handleSelect"
        background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
        <el-menu-item index="1">工作查询与学生信息</el-menu-item>
      
            <el-menu-item index="2">互测分组查看</el-menu-item>

          
       
        <el-menu-item index="3">提交代码工程文件</el-menu-item>
        
       

    </el-menu>
</template>

<script>
export default {
    name:'StudentHeaderTap',
    data() {
        return {
            activeIndex: '2-3',
            activeIndex2:'1',
            
        };
    },
    methods: {
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        },

    }
}
</script>