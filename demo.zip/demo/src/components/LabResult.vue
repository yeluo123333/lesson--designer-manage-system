<template>
    <div class="container">
        <div class="header">
            <h1 style="color: aliceblue;">南京农业大学人工智能学院操作系统课程实验室成果展示</h1>

        </div>
        <div style="width: 30%; margin-left: 19%;">
            <h3 style="color: aliceblue;text-indent: 2em;">
                操作系统是一种控制和管理计算机硬件、软件和资源的系统软件。它充当计算机硬件和应用程序之间的中介，为用户和应用程序提供简单的、统一的接口，并管理计算机系统中的各种资源，如内存、CPU、磁盘、网络等。操作系统还提供了一些重要的功能，如进程管理、内存管理、文件系统、网络管理和安全管理等。通过操作系统，计算机可以实现高效、可靠和安全地运行各种应用程序。
            </h3>
        </div>
        <div class="main">
            <div class="gallery">
                <div class="gallery-item" v-for="item in items" :key="item.id">
                    <img :src="item.imageUrl" :alt="item.title">
                    <div class="gallery-item-overlay">
                        <router-link to="/login">
                            <h2>{{ item.title }}</h2>
                        </router-link>
                        <p>{{ item.description }}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <p>版权所有 © 2023 南京农业大学人工智能学院</p>
        </div>
    </div>
</template>
  
<script>

export default {
    name: 'LabResults',
    data() {
        return {
            items: [
                {
                    id: 1,
                    title: "Linux系统实验",
                    description: "帮助学生合理理解Linux指令系统并且进行基础的指令理解和操作",
                    imageUrl: "https://file.elecfans.com/web1/M00/C4/E8/o4YBAF9FxwWAB-hiAAB56v2sGGM187.jpg",
                },
                {
                    id: 2,
                    title: "操作系统课程设计",
                    description: "帮助本科生进行操作系统理论的深入理解，并且掌握多线程编程",
                    imageUrl: "https://img0.baidu.com/it/u=39407089,2158131041&fm=253&fmt=auto&app=138&f=JPEG?w=577&h=388",
                },
                {
                    id: 3,
                    title: "Srt申请题目与成果",
                    description: "成果描述 3",
                    imageUrl: "https://img0.baidu.com/it/u=1296757531,464336757&fm=253&fmt=auto&app=138&f=PNG?w=500&h=376",
                },
            ],
        };
    },
    methods: {


    }
};
</script>
  
<style scoped>
.container {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

.header {

    padding: 20px;
    text-align: center;
}

.main {
    flex: 1;

    background-position: center center;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
}

.gallery {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.gallery-item {
    position: relative;
    margin: 10px;
    width: 300px;
    height: 200px;
}

.gallery-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.gallery-item-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: opacity 0.2s ease;
}

.gallery-item:hover .gallery-item-overlay {
    opacity: 1;
}

.gallery-item-overlay h2,
.gallery-item-overlay p {
    margin: 0;
    padding: 0;
}

.footer {
    background-color: #333;
    color: #fff;
    padding: 10px;
    text-align: center;
}
</style>
  
  