<template>
    <div>
        <el-table :data="tableData" stripe style="width: 100%">
            <el-table-column prop="student_name" label="原学生姓名">
            </el-table-column>
            <el-table-column prop="student_name1" label="互测学生" v-for="item in items" :key="item">
                <el-row style="margin-left: 45%;">
                    <el-button type="success" icon="el-icon-download" circle size="mini"></el-button>
                </el-row>
            </el-table-column>
        </el-table>
    </div>
</template>
  
<script>
export default {
    name: ' StudentnameList',
    data() {
        return {
            tableData: [{}]
        }
    },
    props: {
        message: {
            type: String,
            required: true
        }
    },
    computed: {
        items() {
            let maxNum = parseInt(this.message)
            let result = [];
            for (let i = 0; i < maxNum; i++) {
                result.push(i);
            }
            let index = this.maxNumber;
            while (index < 10) {
                result.push(index++);
            }
            return result;
        }
    }
}
</script>