<template>
    <el-menu :default-active="activeIndex2" class="el-menu-demo" mode="horizontal" @select="handleSelect"
        background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
        <el-menu-item index="1">互测分组</el-menu-item>
        <el-submenu index="2">
            <template slot="title">工作台</template>
            <el-menu-item index="2-1">代码查重</el-menu-item>
            <el-menu-item index="2-2">工程结构查询</el-menu-item>
            <el-menu-item index="2-3">注视比例查看</el-menu-item>
          
        </el-submenu>
        <el-menu-item index="3">设置管理</el-menu-item>
        
       

    </el-menu>
</template>

<script>
export default {
    name:'HeaderTap',
    data() {
        return {
            activeIndex: '2-3',
            activeIndex2:'1',
            
        };
    },
    methods: {
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        },

    }
}
</script>
