import Vue from 'vue';
import Router from 'vue-router';
import Loginstd from '../components/Loginstd.vue';
import LabResults from '../components/LabResult.vue'
import teacher_index from '../components/teacher_index.vue'
import studentWork from '../components/Studentwork.vue'
Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/login',
      name: 'Loginstd',
      component: Loginstd,
    },
    {
      path:'/main',
      name:'teacher_index',
      component:teacher_index
    },
    {
      path:'/',
      name:'Lab',
      component:LabResults
    },
    {
      path:'/student',
      component:studentWork
    }
  ],
});

