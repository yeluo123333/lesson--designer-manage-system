<template>
    <div> 
         
          <router-view/>    
    </div>
</template>


<script>
//import Login from './components/Loginstd.vue';
export default {
    name: 'App',
    components: {

    }
}
</script>